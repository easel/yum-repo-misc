npm-prefix(3) -- Display prefix
===============================

## SYNOPSIS

    npm.commands.prefix(args, callback)

## DESCRIPTION

Print the prefix to standard out.

'args' is never used and callback is never called with data.
'args' must be present or things will break.

This function is not useful programmatically
