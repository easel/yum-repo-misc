package TA::C::A::I;

sub foo { }

package TA::C::A::I::A;

sub foo { }

package TA::C::A::I::A::B;

sub foo { }

1;
